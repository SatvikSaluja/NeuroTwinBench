## Primary grid — first result

Generated from durable per-class checkpoints; no pooled E/I correlations.

Completed grids: **2 independent base-seed recordings** (100, 200, 300 as available).
Across-seed SD is unavailable for a single seed, rather than reported as zero.

The old grid stopped after one console-only pooled result and wrote no JSON; that number is not used.
New fits use LBFGS/float32, five basis functions, ridge 1e-3, and exclude history across independent chunks.
The 16.1 synthetic spikes/predictor observation is a budget reference, not a sufficiency threshold for HNN.

Each receptor/location class is retained. Shared pairs have one total inferred influence, so these are not independent receptor/location recoveries.
Autapses are excluded; inhibitory weight ranks are unavailable because their spread is degenerate (§2F).
Production baselines cover the full-population/true-drive condition. Other grid cells are exploratory contrasts until matched controls are available.

**L2_pyramidal->L2_basket|ampa|soma**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.725 ± 0.000 | +0.724 ± 0.000 | +0.725 ± 0.000 |
| interneurons_hidden | -- | -- | -- |
| random_subsample | +0.777 ± 0.014 | +0.776 ± 0.015 | +0.777 ± 0.014 |

**L2_pyramidal->L2_pyramidal|ampa|proximal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.311 ± 0.002 | +0.311 ± 0.002 | +0.311 ± 0.003 |
| interneurons_hidden | +0.276 ± 0.005 | +0.278 ± 0.005 | +0.277 ± 0.005 |
| random_subsample | +0.215 ± 0.031 | +0.216 ± 0.030 | +0.215 ± 0.031 |

**L2_pyramidal->L2_pyramidal|nmda|proximal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.311 ± 0.002 | +0.311 ± 0.002 | +0.311 ± 0.003 |
| interneurons_hidden | +0.276 ± 0.005 | +0.278 ± 0.005 | +0.277 ± 0.005 |
| random_subsample | +0.215 ± 0.031 | +0.216 ± 0.030 | +0.215 ± 0.031 |

**L2_pyramidal->L5_basket|ampa|soma**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.702 ± 0.005 | +0.701 ± 0.005 | +0.702 ± 0.005 |
| interneurons_hidden | -- | -- | -- |
| random_subsample | +0.744 ± 0.027 | +0.743 ± 0.027 | +0.744 ± 0.026 |

**L2_pyramidal->L5_pyramidal|ampa|distal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.108 ± 0.014 | +0.108 ± 0.013 | +0.108 ± 0.013 |
| interneurons_hidden | -0.078 ± 0.010 | -0.078 ± 0.010 | -0.078 ± 0.010 |
| random_subsample | +0.140 ± 0.026 | +0.140 ± 0.027 | +0.140 ± 0.027 |

**L2_pyramidal->L5_pyramidal|ampa|proximal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.108 ± 0.014 | +0.108 ± 0.013 | +0.108 ± 0.013 |
| interneurons_hidden | -0.078 ± 0.010 | -0.078 ± 0.010 | -0.078 ± 0.010 |
| random_subsample | +0.140 ± 0.026 | +0.140 ± 0.027 | +0.140 ± 0.027 |

**L5_pyramidal->L5_basket|ampa|soma**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.387 ± 0.005 | +0.388 ± 0.006 | +0.388 ± 0.005 |
| interneurons_hidden | -- | -- | -- |
| random_subsample | +0.364 ± 0.048 | +0.364 ± 0.047 | +0.364 ± 0.049 |

**L5_pyramidal->L5_pyramidal|ampa|proximal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.494 ± 0.001 | +0.494 ± 0.001 | +0.494 ± 0.001 |
| interneurons_hidden | +0.503 ± 0.006 | +0.503 ± 0.006 | +0.503 ± 0.006 |
| random_subsample | +0.509 ± 0.003 | +0.509 ± 0.002 | +0.509 ± 0.002 |

**L5_pyramidal->L5_pyramidal|nmda|proximal**

| Observed population | True drive | Proxy | Hidden |
|---|---:|---:|---:|
| full | +0.494 ± 0.001 | +0.494 ± 0.001 | +0.494 ± 0.001 |
| interneurons_hidden | +0.503 ± 0.006 | +0.503 ± 0.006 | +0.503 ± 0.006 |
| random_subsample | +0.509 ± 0.003 | +0.509 ± 0.002 | +0.509 ± 0.002 |

True→proxy→hidden recovery decreases monotonically in 1/24 scoreable class/population combinations.
This is descriptive; class overlap and seed count preclude a significance claim.

Interneuron-hidden minus random-subsample recovery ranges from -0.218 to +0.062 across common scoreable classes/drive conditions.
These masks retain different pairs; this contrast also changes the evaluation set.

Fits not satisfying the recorded solver stopping criterion: 6/18. Their scores are provisional, not validated scientific findings.

**Seed 100 baselines** (complete=True)

| Connection class | Population | Pairwise + drive | CCG | Jitter + drive |
|---|---:|---:|---:|---:|
| L2_pyramidal->L2_basket|ampa|soma | +0.725 | +0.687 | +0.488 | +0.594 |
| L2_pyramidal->L2_pyramidal|ampa|proximal | +0.309 | +0.047 | +0.461 | +0.494 |
| L2_pyramidal->L2_pyramidal|nmda|proximal | +0.309 | +0.047 | +0.461 | +0.494 |
| L2_pyramidal->L5_basket|ampa|soma | +0.705 | +0.584 | +0.343 | +0.557 |
| L2_pyramidal->L5_pyramidal|ampa|distal | +0.118 | +0.318 | +0.509 | +0.533 |
| L2_pyramidal->L5_pyramidal|ampa|proximal | +0.118 | +0.318 | +0.509 | +0.533 |
| L5_pyramidal->L5_basket|ampa|soma | +0.391 | +0.390 | +0.578 | +0.540 |
| L5_pyramidal->L5_pyramidal|ampa|proximal | +0.494 | +0.468 | +0.638 | +0.633 |
| L5_pyramidal->L5_pyramidal|nmda|proximal | +0.494 | +0.468 | +0.638 | +0.633 |

No advantage for joint estimation is assumed; compare each population score directly with its pairwise and null scores.

**Latency calibration (§6)**

No adjacent lag separation was resolved.
This is a one-seed, across-edge dispersion criterion on basis-aligned lags, not a universal timing resolution.

